#pragma once
#pragma once
#include "JuceHeader.h"

class DuplicateChecker
{
    public :
    DuplicateChecker(){}
    void prepare()
    {
        std::fill(notesOn, notesOn + 127, false);
    }
    void process(juce::MidiBuffer& midiMessages)
    {
        midiBuffer.clear();
        for (auto message : midiMessages)
        {
            auto currentMessage = message.getMessage();
            auto noteNum = currentMessage.getNoteNumber();
            auto position = message.samplePosition;
            if (currentMessage.isNoteOn())
            {
                
                
                if (notesOn[noteNum]  == true)
                {
                    DBG("NoteOnRequested" + juce::String(noteNum));
                }
                
                if (notesOn[noteNum]  == false)
                {
                    DBG("/////////////A new note on Has Appeared:" + juce::String(noteNum));
                    currentMessage.setNoteNumber(noteNum);
                    midiBuffer.addEvent(currentMessage, position);
                    notesOn[noteNum] = true;
                    noteOnSet.add(noteNum);
                   // DBG("NoteOnRequested" + juce::String(notesOn[noteNum]));
                }
                

            }
            
            if (currentMessage.isNoteOff())
            {
                if (notesOn[noteNum]  == false)
                {
                    DBG("NoteOffRequested" + juce::String(noteNum));
                }
                
                if (notesOn[noteNum] == true)
                {
                    DBG("/////////////A new note off Has Appeared:" + juce::String(noteNum));
                   // DBG("NoteOffRequested" + juce::String(notesOn[noteNum]));
                    
                    currentMessage.setNoteNumber(noteNum);
                    midiBuffer.addEvent(currentMessage, position);
                    notesOn[noteNum] = false;
                    noteOnSet.remove(noteNum);
                }
                

                
            }
        }
//        if (!noteOnSet.isEmpty())
//        {
//            DBG(noteOnSet.size());
//        }
        midiMessages.swapWith(midiBuffer);
    }
    
private:
    bool notesOn[127];
    juce::MidiBuffer midiBuffer;
    juce::SortedSet<int> noteOnSet;
    juce::SortedSet<int> noteOffSet;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DuplicateChecker)
};
