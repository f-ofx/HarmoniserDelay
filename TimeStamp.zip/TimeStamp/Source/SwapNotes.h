/*
  ==============================================================================

    SwapNotes.h
    Created: 25 Nov 2022 6:07:44pm
    Author:  Mouldy Soul

  ==============================================================================
*/

#pragma once
/*
 ==============================================================================
 
 DelayNote.h
 Created: 25 Nov 2022 5:51:25pm
 Author:  Mouldy Soul
 
 ==============================================================================
 */

#pragma once
#include "NoteInfo.h"

class SwapNotes
{
    public :
    
    void process(juce::MidiBuffer& midiMessages, juce::Array<uint>& notes, Notes& notesInfo)
    {
        for (auto message : midiMessages)
        {
            auto currentMessage = message.getMessage();
            int noteNum = currentMessage.getNoteNumber();
            int velocity = currentMessage.getVelocity();
            int position = message.samplePosition;
            
            if (currentMessage.isNoteOn())
            {
                //DBG(juce::String(notes.getLast()));
               // DBG(juce::String(notesInfo[0].noteNum));
            }
            
            if (currentMessage.isNoteOff())
            {
                //notes.remove(noteNum);
            }
        }
    }
};
